# Birthday Cake Candles Problem
Difficulty Level: Easy

Algorithms Stragies Used: Linear Search

Instructions to Test/Confirm: https://www.hackerrank.com/challenges/birthday-cake-candles/problem, copy-paste CPP file into coding area or use "Upload code as file"